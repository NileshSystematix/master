// Main module of the app.
angular.module('starter.controllers', ['ionic'])

// Home screen Controller
.controller('homeController', function($scope, $ionicHistory, $location) {
    // Back button functionality.
    $scope.GoBack = function () {
        $ionicHistory.goBack();
    }


//Video screen redirection
$scope.watchVideo = function() {
  $location.path('/video')
  };

  // See Check List screen redirection 
  $scope.seeCheckList = function() {
    
  $location.path('/seeCheckList')
  };

  // Home button funtionality
  $scope.homePage = function() {
    $location.path('/home')
  };

  // Social Shring redirection functionality
  $scope.socialSharing = function() {

        $location.path('/socialSharing')
      }
})

//See Check List screen controller
.controller('seeCheckListController', function($scope, $ionicHistory, $location) {
    $scope.documentation = function () {
        $location.path('/documentation')
    }
  })

//Documentation screen controller
.controller('documentationController', function($scope, $ionicHistory, $location) {
    // Steps screen redirection
    $scope.steps = function () {
       $location.path('/steps')
    }
  })

//Steps screen controller
.controller('stepsController', function($scope, $ionicHistory, $location) {
     //Conclusion screen redirection
     $scope.conclusion = function () {
        $location.path('/conclusion')
     }
  })

// Final Check List Controller
.controller('finalCheckController', function($scope, $ionicHistory, $location) {
     
     // Video screen redirection
     $scope.watchVideo = function() {
        $location.path('/video')
      }
     

  })

.controller('videoController', function($scope, $ionicHistory, $location) {

  // onSuccess Callback
// This method accepts a JSON object, which contains the
// boolean response
//

$scope.testme = function(){
window.cordova.plugins.FileOpener.openFile("http://www.website.com/file.pdf", onSuccess, onError);

var onSuccess = function(data) {
    alert('extension: ' + data.extension + '\n' +
          'canBeOpen: ' + data.canBeOpen);
};

// onError Callback receives a json object
//
function onError(error) {
    alert('message: '  + error.message);
}

}


})

//Conclusion screen controller
.controller('conclusionController', function($scope, $ionicHistory, $location) {
      // Final Check List redirection
      $scope.checkoff = function () {
                  
          $location.path('/checkOff')
    
     }
  })


//Social Sharing screen controller
.controller('socialSharingController', function($scope, $ionicHistory, $location, $cordovaSocialSharing) {
    
   // Twitter social sharing functionality 
   $scope.shareViaTwitter = function() {
     
     window.plugins.spinnerDialog.show("Loading...","Please wait...", true); 
       
     var message ="MagMutual";
        $cordovaSocialSharing.canShareVia("twitter", "message", null, "http://www.hashtagmed.com/magmutual/ShoulderDystocia.pdf").then(function(result) {
        $cordovaSocialSharing.shareViaTwitter(message, null, "http://www.hashtagmed.com/magmutual/ShoulderDystocia.pdf");
        $scope.delayLoader();
        }, function(error) {
          window.plugins.spinnerDialog.hide();
            alert("Sharing on Twitter has been failed.");
        });
    }   
     
     // Facebook social sharing functionality
       $scope.shareViaFacebook = function() {
         var message ="MagMutual";
         window.plugins.spinnerDialog.show("Loading...","Please wait...", true); 
           $scope.delayLoader();
        $cordovaSocialSharing.canShareVia("facebook", "message", null, "http://www.hashtagmed.com/magmutual/ShoulderDystocia.pdf").then(function(result) {
            $cordovaSocialSharing.shareViaFacebook(message, null, "http://www.hashtagmed.com/magmutual/ShoulderDystocia.pdf");
            $scope.delayLoader();
        }, function(error) {
          window.plugins.spinnerDialog.hide();
            alert("Sharing on Facebook has been failed.");
        });
    } 
    
    // Cancel button functionality of social sharing screen which will redirect to home screen
    $scope.cancel = function () {
          $location.path('/home')
     }
    
    $scope.delayLoader = function()
    {
      setTimeout(function(){
      window.plugins.spinnerDialog.hide();
      
    }, 5000);
    }
   })




 


